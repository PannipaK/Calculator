//Auther:Pannipa Khumduang
//Date:11/13/2020
//Assignment:11 Calculator Part 1  
//Class:CIS016

package calculatorPart1;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class calculatorPart1 extends Application {
	@Override
	   public void start(Stage stage) {
	      //Creating a Button
	      Button[] button = new Button[10];
	      for (int i=0; i<10; i++) {
	          button[i] = new Button();
	          //Setting text to the button
	          button[i].setText(String.format("%d", i));
	      }
	      Button[] operators = new Button[5];
	      for (int i=0; i<5; i++) {
	          operators[i] = new Button();
	      }
	      operators[0].setText("/");
	      operators[1].setText("*");
	      operators[2].setText("-");
	      operators[3].setText("+");
	      operators[4].setText("=");

	      operators[0].setTranslateX(100);
	      operators[0].setTranslateY(0);
	      operators[1].setTranslateX(100);
	      operators[1].setTranslateY(30);
	      operators[2].setTranslateX(100);
	      operators[2].setTranslateY(60);
	      operators[3].setTranslateX(100);
	      operators[3].setTranslateY(90);


	      //Setting the location of the button
	      // 0 button
	      button[0].setTranslateX(10);
	      button[0].setTranslateY(120);

	      // bottom row
	      button[1].setTranslateX(10);
	      button[2].setTranslateX(40);
	      button[3].setTranslateX(70);
	      button[1].setTranslateY(90);
	      button[2].setTranslateY(90);
	      button[3].setTranslateY(90);

	      // middle row
	      button[4].setTranslateX(10);
	      button[5].setTranslateX(40);
	      button[6].setTranslateX(70);
	      button[4].setTranslateY(60);
	      button[5].setTranslateY(60);
	      button[6].setTranslateY(60);

	      // top row
	      button[7].setTranslateX(10);
	      button[8].setTranslateX(40);
	      button[9].setTranslateX(70);
	      button[7].setTranslateY(30);
	      button[8].setTranslateY(30);
	      button[9].setTranslateY(30);

	      //Setting the stage
	      Group root = new Group(button);
	      Scene scene = new Scene(root, 595, 150, Color.BEIGE);
	      stage.setTitle("Calculator");
	      stage.setScene(scene);
	      stage.show();
	   }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

}
